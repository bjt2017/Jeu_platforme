import pygame
import display
playing = False
d = display.Display(1280,720)
button_option = [pygame.image.load('assets/menu/Icons_39.png'),pygame.image.load('assets/menu/Icons_40.png'),pygame.image.load('assets/menu/Icons_39.png').get_rect(),0]
button_play = [pygame.image.load('assets/menu/menue2.png'),pygame.image.load('assets/menu/menue1.png'),pygame.image.load('assets/menu/Icons_39.png').get_rect(),0]
all_button = [button_option,button_play]
clic = 0
#d.resize(1920,1080) #FHD
#d.resize(3840,2160) #4k

while True:
    x,y = pygame.display.get_window_size()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            quit()
        if playing==False:
            if event.type == pygame.MOUSEMOTION:
                for button in all_button:
                    if button[2].collidepoint(event.pos):button[3] = 1
                    else:button[3] = 0

    if playing==False:
        d.blit(pygame.image.load('assets/background/brown.png'),1280,720)
        d.blit(pygame.image.load('assets/menu/menu01.png'),700,550,290,100)
        d.blit(pygame.image.load('assets/menu/Logo.png'), 424, 192,428,0)
        if clic == 0:
            button_option[2] = d.blit(button_option[button_option[3]],48,48,340,150,button_option[2])
            button_play[2] = d.blit(button_play[button_play[3]], 288, 66, 500, 200, button_play[2])
        if clic == 1:
            pass
    d.update()


