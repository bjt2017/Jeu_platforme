import pygame
class Display:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.screen = pygame.display.set_mode((x, y))
        self.mode = {'4k':[3840,2160,240],'FHD':[1920,1080,120],'HD':[1280,720,80]}
        self.raport = 1
    def update(self):
        pygame.display.update()
    def resize(self,x,y):
        last_size = pygame.display.get_window_size()
        print(x/last_size[0])
        pygame.quit()
        self.screen = pygame.display.set_mode((x, y))
        self.raport = x/1280
    def blit(self,surface,tx,ty,x=0,y=0,rect=None):
        self.screen.blit(pygame.transform.scale(surface,(tx*self.raport,ty*self.raport)),(x*self.raport,y*self.raport))
        if rect!=None:
            rect.x = x*self.raport
            rect.y = y*self.raport
            rect.width = tx*self.raport
            rect.height = ty*self.raport
            return rect




